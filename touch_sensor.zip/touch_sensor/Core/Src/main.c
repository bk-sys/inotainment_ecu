/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Passenger Seatbelt / Infotainment ECU
  * CAN ID: 0x108 | data[0]=passenger | data[1]=seatbelt
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include <string.h>
#include <stdio.h>

/* USER CODE BEGIN PD */
#define LED_GREEN          GPIO_PIN_12
#define LED_ORANGE         GPIO_PIN_13
#define LED_RED            GPIO_PIN_14
#define LED_BLUE           GPIO_PIN_15   /* CAN TX success indicator */
#define LED_PORT           GPIOD

#define SEATBELT_CAN_ID    0x108U   /* FIXED: was 0x123, must match CANEasy .dbc */
/* USER CODE END PD */

CAN_HandleTypeDef  hcan1;
UART_HandleTypeDef huart2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_CAN1_Init(void);

/* USER CODE BEGIN PFP */
static void              send_uart(const char *msg);
static void              set_led_only(uint16_t led);
static void              blink_blue_tx(void);
static HAL_StatusTypeDef CAN_SendFrame2(uint32_t id, uint8_t passenger, uint8_t belt);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
static void send_uart(const char *msg)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)msg, (uint16_t)strlen(msg), HAL_MAX_DELAY);
}

static void set_led_only(uint16_t led)
{
    /* Clear all status LEDs (green / orange / red) but leave blue alone */
    HAL_GPIO_WritePin(LED_PORT, LED_GREEN | LED_ORANGE | LED_RED, GPIO_PIN_RESET);
    if (led)
        HAL_GPIO_WritePin(LED_PORT, led, GPIO_PIN_SET);
}

/*
 * Blinks the blue LED (PD15) once to confirm a successful CAN TX.
 * 100 ms ON so it is clearly visible even at 500 ms loop rate.
 */
static void blink_blue_tx(void)
{
    HAL_GPIO_WritePin(LED_PORT, LED_BLUE, GPIO_PIN_SET);
    HAL_Delay(100);
    HAL_GPIO_WritePin(LED_PORT, LED_BLUE, GPIO_PIN_RESET);
}

/*
 * Sends a 2-byte CAN frame:
 *   data[0] = passenger  (0x00 = absent, 0x01 = present)
 *   data[1] = seatbelt   (0x00 = off,    0x01 = on)
 * CANEasy maps these to the "passenger" and "seatbelt" signals under 0x108
 */
static HAL_StatusTypeDef CAN_SendFrame2(uint32_t id, uint8_t passenger, uint8_t belt)
{
    CAN_TxHeaderTypeDef hdr;
    uint8_t  buf[2] = { passenger, belt };
    uint32_t mailbox;

    hdr.StdId              = id;
    hdr.IDE                = CAN_ID_STD;
    hdr.RTR                = CAN_RTR_DATA;
    hdr.DLC                = 2;           /* 2 bytes: passenger + seatbelt */
    hdr.TransmitGlobalTime = DISABLE;

    return HAL_CAN_AddTxMessage(&hcan1, &hdr, buf, &mailbox);
}
/* USER CODE END 0 */

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART2_UART_Init();
    MX_CAN1_Init();

    /* USER CODE BEGIN 2 */

    /* CAN filter — accept ALL frames into FIFO0 */
    CAN_FilterTypeDef cf = {0};
    cf.FilterActivation     = ENABLE;
    cf.FilterBank           = 0;
    cf.FilterFIFOAssignment = CAN_FILTER_FIFO0;
    cf.FilterMode           = CAN_FILTERMODE_IDMASK;
    cf.FilterScale          = CAN_FILTERSCALE_32BIT;
    cf.FilterIdHigh         = 0x0000;
    cf.FilterIdLow          = 0x0000;
    cf.FilterMaskIdHigh     = 0x0000;
    cf.FilterMaskIdLow      = 0x0000;
    cf.SlaveStartFilterBank = 14;

    if (HAL_CAN_ConfigFilter(&hcan1, &cf) != HAL_OK) Error_Handler();
    if (HAL_CAN_Start(&hcan1) != HAL_OK)             Error_Handler();

    HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);

    send_uart("\033[2J\033[H");
    send_uart("=== SEATBELT / INFOTAINMENT ECU READY ===\r\n");
    send_uart("[TX] ID    | ECU          | P  | B  | Status\r\n");
    send_uart("-----------------------------------------------------\r\n");
    send_uart("[RX] 0x101 | ABS ECU      | Brake cmd + ABS + Immob status\r\n");
    send_uart("[RX] 0x102 | ABS ECU      | ABS status + Speed + Temp\r\n");
    send_uart("[RX] 0x117 | ABS ECU      | Telematics ABS fault status\r\n");
    send_uart("-----------------------------------------------------\r\n");

    /* USER CODE END 2 */

    while (1)
    {
        /* USER CODE BEGIN 3 */

        GPIO_PinState ir    = HAL_GPIO_ReadPin(ir_GPIO_Port,    ir_Pin);
        GPIO_PinState touch = HAL_GPIO_ReadPin(touch_GPIO_Port, touch_Pin);

        if (ir == GPIO_PIN_SET)
        {
            /* IR blocked = seat empty, no passenger */
            set_led_only(LED_ORANGE);
            send_uart("[TX] 0x108 | Seatbelt ECU | 00 | 00 | No Passenger\r\n");

            if (CAN_SendFrame2(SEATBELT_CAN_ID, 0x00, 0x00) == HAL_OK)
            {
                blink_blue_tx();
            }
        }
        else if (touch == GPIO_PIN_SET)
        {
            /* IR clear + touch HIGH = passenger sitting, belt buckled */
            set_led_only(LED_GREEN);
            send_uart("[TX] 0x108 | Seatbelt ECU | 01 | 01 | Passenger Present | Belt ON\r\n");

            if (CAN_SendFrame2(SEATBELT_CAN_ID, 0x01, 0x01) == HAL_OK)
            {
                blink_blue_tx();
            }
        }
        else
        {
            /* IR clear + touch LOW = passenger sitting, belt NOT buckled */
            set_led_only(LED_RED);
            send_uart("[TX] 0x108 | Seatbelt ECU | 01 | 00 | Passenger Present | Belt OFF!\r\n");

            if (CAN_SendFrame2(SEATBELT_CAN_ID, 0x01, 0x00) == HAL_OK)
            {
                blink_blue_tx();
            }
        }

        HAL_Delay(500);

        /* USER CODE END 3 */
    }
}

/* USER CODE BEGIN 4 */
/* ====================================================================
   INTERRUPT CALLBACK — fires the instant any CAN frame arrives
==================================================================== */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef hdr;
    uint8_t  data[8];
    char     line[160];
    char     detail[80];

    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &hdr, data) != HAL_OK)
        return;

    /* Ignore our own TX echo */
    if (hdr.StdId == SEATBELT_CAN_ID)
        return;

    const char *node = "Unknown    ";
    const char *desc = "";

    switch (hdr.StdId)
    {
        /* ---- Airbag ECU 0x100 ---- */
        case 0x100:
            node = "Airbag ECU ";
            switch (data[0])
            {
                case 0x00: desc = "Normal / No crash";       break;
                case 0x01: desc = "Crash detected!";         break;
                case 0x02: desc = "Airbag deployed";         break;
                default:   desc = "Unknown state";           break;
            }
            break;

        /* ---- ABS ECU — brake command to BMS (0x101) ---- */
        /* TX format: [brake_cmd_pct (1 byte)]              */
        /* Updated: only 1 byte from latest ABS TX code     */
            case 0x101:
                node = "ABS ECU";
                snprintf(detail, sizeof(detail),
                         "Brake=%u%%  Handbrake=%u",
                         data[0], data[1]);
                desc = detail;
                break;

        /* ---- ABS ECU — status + speed (0x102) ---- */
        /* TX format: [status, speed_int, speed_dec]        */
        /* status: 0x00=normal, 0x01=ABS active,            */
        /*         0x02=temp fault/ABS disabled              */
        case 0x102:
            node = "ABS ECU    ";
            switch (data[0])
            {
                case 0x00:
                    snprintf(detail, sizeof(detail),
                             "Brakes normal      | Speed=%u.%u kmh",
                             data[1], data[2]);
                    break;
                case 0x01:
                    snprintf(detail, sizeof(detail),
                             "ABS ACTIVE         | Speed=%u.%u kmh",
                             data[1], data[2]);
                    break;
                case 0x02:
                    snprintf(detail, sizeof(detail),
                             "ABS FAULT/DISABLED | Speed=%u.%u kmh | Temp CRITICAL",
                             data[1], data[2]);
                    break;
                default:
                    snprintf(detail, sizeof(detail),
                             "Unknown 0x%02X       | Speed=%u.%u kmh",
                             data[0], data[1], data[2]);
                    break;
            }
            desc = detail;
            break;

        /* ---- Engine ECU 0x103 ---- */
        case 0x103:
            node = "Engine ECU ";
            switch (data[0])
            {
                case 0x01: desc = "Engine off";              break;
                case 0x02: desc = "Engine running / normal"; break;
                case 0x03: desc = "Engine warning";          break;
                case 0x04: desc = "Engine critical fault";   break;
                case 0x05: desc = "ENGINE_COOLANT_FAULT";   break;
                case 0x06: desc = "ENGINE_SPORT_MODE";   break;
                default:   desc = "Unknown state";           break;
            }
            break;

        /* ---- Transmission ECU 0x104 ---- */
        case 0x104:
        {
            node = "Trans ECU  ";
            if      (data[0] == 0x01) desc = "Drive";
            else if (data[1] == 0x01) desc = "Sport";
            else if (data[2] == 0x01) desc = "Park";
            else if (data[3] == 0x01) desc = "Neutral";
            else if (data[4] == 0x01) desc = "Reverse";
            else desc = "Unknown state";
        }
            break;

        /* ---- Battery ECU 0x105 ---- */
        case 0x105:
        {
            node = "Battery ECU";

            uint8_t  batt_status = data[0];
            uint16_t temp1_raw   = (data[1] << 8) | data[2];
            uint16_t temp2_raw   = (data[3] << 8) | data[4];
            float    temp1       = temp1_raw / 100.0f;
            float    temp2       = temp2_raw / 100.0f;
            uint8_t  soc         = data[5];
            uint8_t  gear        = data[6];
            uint8_t  brake_pct   = data[7];

            const char *status_str;
            switch (batt_status)
            {
                case 0x00: status_str = "Battery OK";       break;
                case 0x01: status_str = "Battery LOW";      break;
                case 0x02: status_str = "Battery CRITICAL"; break;
                case 0x03: status_str = "Charging ACTIVE";  break;
                default:   status_str = "Unknown";          break;
            }

            snprintf(detail, sizeof(detail),
                     "%s | T1=%.1fC | T2=%.1fC | SOC=%u%% | Gear=0x%02X | Brake=%u%%",
                     status_str, temp1, temp2, soc, gear, brake_pct);
            desc = detail;
        }
        break;

        /* ---- Body ECU 0x106 ---- */
        case 0x106:
            node = "Body ECU   ";
            switch (data[0])
            {
                case 0x99: desc = "LOCKED";        break;
                case 0x11: desc = "UNLOCKED";      break;
                case 0x21: desc = "WINDOW UP";     break;
                case 0x22: desc = "WINDOW DOWN";   break;
                default:   desc = "Unknown state"; break;
            }
            break;

        /* ---- Telematics ECU 0x107 ---- */
        case 0x107:
            node = "Telematics ";
            switch (data[0])
            {
                case 0x00: desc = "Idle / No data";              break;
                case 0x11: desc = "MOBILIZE COMMAND RECEIVED";   break;
                case 0x99: desc = "IMMOBILIZE COMMAND RECEIVED"; break;
                default:   desc = "Unknown state";               break;
            }
            break;

        /* ---- ABS ECU — telematics ABS fault status (0x117) ---- */
        /* TX format: [abs_status_byte (1 byte)]                    */
        /* 0x00 = normal, 0x01 = ABS active, 0x02 = ABS fault      */
        case 0x117:
        {
            node = "ABS ECU    ";
            switch (data[0])
            {
                case 0x00:
                    desc = "ABS Normal     | No fault";
                    break;
                case 0x01:
                    desc = "ABS ACTIVE     | Slip detected";
                    break;
                case 0x02:
                    desc = "ABS FAULT      | Brake temp CRITICAL - ABS disabled";
                    break;
                default:
                    snprintf(detail, sizeof(detail),
                             "Unknown ABS status 0x%02X", data[0]);
                    desc = detail;
                    break;
            }
        }
        break;

        default:
            node = "Unknown    ";
            desc = "N/A";
            break;
    }

    snprintf(line, sizeof(line), "[RX] 0x%03lX | %-11s | 0x%02X | %s\r\n",
             (unsigned long)hdr.StdId, node, data[0], desc);
    send_uart(line);
}
/* USER CODE END 4 */

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM       = 4;
    RCC_OscInitStruct.PLL.PLLN       = 168;
    RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ       = 7;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                     | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) Error_Handler();
}

static void MX_CAN1_Init(void)
{
    hcan1.Instance                  = CAN1;
    hcan1.Init.Prescaler            = 6;
    hcan1.Init.Mode                 = CAN_MODE_NORMAL;
    hcan1.Init.SyncJumpWidth        = CAN_SJW_1TQ;
    hcan1.Init.TimeSeg1             = CAN_BS1_11TQ;
    hcan1.Init.TimeSeg2             = CAN_BS2_2TQ;
    hcan1.Init.TimeTriggeredMode    = DISABLE;
    hcan1.Init.AutoBusOff           = ENABLE;
    hcan1.Init.AutoWakeUp           = DISABLE;
    hcan1.Init.AutoRetransmission   = ENABLE;
    hcan1.Init.ReceiveFifoLocked    = DISABLE;
    hcan1.Init.TransmitFifoPriority = DISABLE;
    if (HAL_CAN_Init(&hcan1) != HAL_OK) Error_Handler();
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* LEDs PD12–PD15 (green, orange, red, blue) */
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);
    GPIO_InitStruct.Pin   = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* Touch sensor — active HIGH, pull-down */
    GPIO_InitStruct.Pin  = touch_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    HAL_GPIO_Init(touch_GPIO_Port, &GPIO_InitStruct);

    /* IR sensor — active LOW, pull-up */
    GPIO_InitStruct.Pin  = ir_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(ir_GPIO_Port, &GPIO_InitStruct);

    /* CAN1 — PD0 (RX), PD1 (TX), AF9 */
    GPIO_InitStruct.Pin       = GPIO_PIN_0 | GPIO_PIN_1;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_CAN1;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) {}
#endif
